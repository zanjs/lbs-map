<template>
    <div class="footer">
        <div>
            <strong>Copyright</strong> &copy; 2016
        </div>
    </div>
</template>