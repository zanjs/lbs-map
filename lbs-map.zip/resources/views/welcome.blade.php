<!DOCTYPE html>
<html>

<head>
    <title>lbs map</title>
<body>
    <div id="l-map">hello</div>
</body>
</html>
<script type="text/javascript" src="/libs/d.js"></script>
